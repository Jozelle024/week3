/*jshint esversion: 6 */
const PI = Math.PI;

module.exports.area = r => PI * r * r;
module.exports.circonferenza = r => 2 * PI * r;


